#AstroGallery.

Ein engelsk nettstad der ein kan dele sine kule astronomi bileter, dele informasjon og data om kule ting som skjer, abonnere til månedlage emailer, og mykje mykje meir.

Har ein stad der ein kan bla nedover og sjå på bileter, eller sjå på mangen samstundes, har også forum.

Bruk "npm install" for å installere alle dependencies og "npm run dev" for å starte nettstaden.

Data og informasjon som poster eller kommentarer er lagret på ein firestore dataserver og ein firebase storage dataserver.

Kjelder:

-   TailwindCSS
-   DaisyUI
-   Firebase
    -   Firestore
    -   Storage
-   Unsplash
    -   Bileter
-   Svgrepo
    -   Ikoner
-   Pexels
    -   Bileter
