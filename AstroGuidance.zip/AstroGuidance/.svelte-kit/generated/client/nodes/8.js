import * as universal from "../../../../src/routes/profile/[slug]/+page.js";
export { universal };
export { default as component } from "../../../../src/routes/profile/[slug]/+page.svelte";