<script>
	import { docStore } from "$lib/docCollectionStore.ts";
	import { dbFireStore, auth } from ".././firebase";
	import { userStore } from "$lib/authStore.ts";
	import { updateFirestoreDocument, deleteFireStoreDocument } from "$lib/updateSetDoc.js";
	import Comment from "$lib/Comment.svelte";
	import MediaGallery from "$lib/MediaGallery.svelte";
	export let postID;
	export let postData = docStore(dbFireStore, `posts/${postID}`);
</script>

<!-- Basically just post-modal but is it's own page.-->
