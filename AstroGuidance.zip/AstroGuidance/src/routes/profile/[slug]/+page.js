export const load = ({ params }) => {
	return {
		slug: params.slug,
	};
};
