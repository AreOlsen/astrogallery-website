<main class="flex flex-col gap-2 justify-center items-center">
	<div
		class="flex flex-col gap-1 justify-center items-center min-h-screen box-content w-full bg-[url('/AboutUsBackground/outerspace.jpg')] bg-center bg-cover"
	>
		<div class="prose lg:prose-xl">
			<h1>
				The forum for <span class="italic">astronomers</span>, <br /> by
				<span class="italic">astronomers</span>. 🔭
			</h1>
			<p>
				We are a subcompany of SpaceX who's aim is to spread the knowledge and understanding of the outer space
				as we know. Our goal is to create a safe united space for all astronomers to meet and share their
				findings.
			</p>
		</div>
		<a href="#section_1" class="flex flex-row gap-2 p-4 border-white border-2 rounded-xl">
			<img src="/Icons/arrowDownwards.svg" alt="Downwards arrow" width="24px" height="24px" />
			<span>Learn More</span>
		</a>
	</div>
	<div id="section_1" class="flex flex-row flex-wrap gap-2 justify-evenly items-center min-h-[75vh] box-content p-4">
		<div class="prose lg:prose-xl">
			<h2>Who are we?</h2>
			<p>
				We are a team of passionate individuals who love all things related to the study of celestial objects
				and phenomena. Our goal is to share our knowledge and enthusiasm with the world, and to inspire others
				to explore the mysteries of the universe. Our team is made up of webdevelopers and computer-scientists,
				astronomers, astrophysicists, educators, and science communicators. We come from a variety of
				backgrounds and have a wide range of expertise, but we are united by our love for astronomy and our
				desire to share it with others.
			</p>
		</div>
		<img src="/AboutUsBackground/developers.jpg" class="w-1/4 rounded-md" alt="The forum developers." />
	</div>
	<div
		id="section_2"
		class="flex flex-row flex-wrap gap-2 justify-evenly items-center min-h-[75vh] box-content p-4 bg-base-200"
	>
		<img src="/AboutUsBackground/research.jpg" class="w-1/3 rounded-md" alt="Research papers and computers." />
		<div class="prose lg:prose-xl">
			<h2>What you will find.</h2>
			<p>
				On this website, you will find a wealth of information about astronomy, from the basics of stargazing to
				the latest discoveries in the field. We offer a range of resources, primarily our forum, but we also
				have articles, videos, podcasts, and interactive tools on our other media, to help you explore the
				wonders of the universe.
			</p>
		</div>
	</div>
	<div id="section_3" class="flex flex-row flex-wrap gap-2 justify-evenly items-center min-h-[75vh] box-content p-4">
		<div class="prose lg:prose-xl">
			<h2>Social events and community activities.</h2>
			<p>
				In addition to our online content, we also offer in-person events and activities, such as star parties,
				telescope workshops, and astronomy camps for kids. We believe that hands-on experiences are essential
				for truly understanding and appreciating the beauty and complexity of the cosmos. We are committed to
				making astronomy accessible to everyone, regardless of their background or level of expertise. Whether
				you are a seasoned astronomer or just starting to explore the wonders of the universe, we have something
				for you.
			</p>
		</div>
		<img src="/AboutUsBackground/event.jpg" class="w-1/4 rounded-md" alt="Latest event we had, stargazing." />
	</div>
</main>
